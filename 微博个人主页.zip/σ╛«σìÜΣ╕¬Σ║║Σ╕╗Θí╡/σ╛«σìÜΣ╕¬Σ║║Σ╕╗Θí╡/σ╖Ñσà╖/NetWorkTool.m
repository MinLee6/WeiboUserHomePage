//
//  NetWorkTool.m
//  微博个人主页
//
//  Created by limin on 17/1/4.
//  Copyright © 2017年 君安信（北京）科技有限公司. All rights reserved.
//

#import "NetWorkTool.h"
#import "AFNetworking.h"

@interface NetWorkTool ()

@end
@implementation NetWorkTool
+ (void)NetRequestWithBaseURL:(NSString*)baseURL andAppendURL:(NSString*)url
                   RequestWay:(NSString*)way
                   Parameters:(id)parameters
                     finished:(void (^)(id data))finished
                      failure:(void (^)(NSError* error))failure
{
    
    // 1.请求管理器
//    AFNetworkReachabilityManager
    AFHTTPSessionManager *sessionManager = [AFHTTPSessionManager manager];
    sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain", nil];
    
    //2.请求的URL
    NSString* urlPath = [baseURL stringByAppendingString:url];
    
    //3.发起请求
    if ([way isEqualToString:@"POST"]) {
        
        [sessionManager POST:urlPath parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
           
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            finished(responseObject);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            failure(error);
        }];
        
    }else if ([way isEqualToString:@"GET"]) {
        [sessionManager GET:urlPath parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            finished(responseObject);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            failure(error);
        }];
        
    }
}

- (void)NetRequestWithBaseURL:(NSString*)baseURL andAppendURL:(NSString*)url
                   RequestWay:(NSString*)way
                   Parameters:(id)parameters
                     finished:(void (^)(id data))finished
                      failure:(void (^)(NSError* error))failure
{
    
    [NetWorkTool NetRequestWithBaseURL:baseURL andAppendURL:url RequestWay:way Parameters:parameters finished:finished failure:failure];
}

@end

