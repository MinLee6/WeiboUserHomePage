//
//  HomePageContentTableVC.h
//  lingfo
//
//  Created by limin on 16/12/28.
//  Copyright © 2016年 anxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageContentTableVC : UIViewController

@property (nonatomic, strong, readonly) UITableView *tableView;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, assign) BOOL allowPullToRefresh;
@property (nonatomic, assign) CGFloat pullOffset;
@property (nonatomic, assign) CGFloat fillHight;  //segmentButtons + segmentTopSpace

/* 数据模型 */
@property(nonatomic,strong)NSArray *modelArray;

@end
