//
//  HomePageContentTableVC.m
//  lingfo
//
//  Created by limin on 16/12/28.
//  Copyright © 2016年 anxin. All rights reserved.
//

#import "HomePageContentTableVC.h"
#import "HHHorizontalPagingView.h"
#import "UIView+WhenTappedBlocks.h"


#import "SVPullToRefresh.h"
#import "LMMyHomeController.h"
@interface HomePageContentTableVC()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *homePageTableView;


@end

@implementation HomePageContentTableVC
#pragma mark - 懒加载

- (void)loadView{
    self.homePageTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    self.homePageTableView.dataSource = self;
    self.homePageTableView.delegate = self;
    [self.homePageTableView setSeparatorColor:GrayColor(231)];
    self.homePageTableView.backgroundColor = kBgColor;
    self.view = self.homePageTableView;
    
    //去掉底部多余的表格线
    [self.homePageTableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    [self solvePlainSeparatorStyle];
    [self setupMsgRefresh];
}
-(void)solvePlainSeparatorStyle
{
    //1.解决Cell下面的线左边15像素空白问题
    if ([self.homePageTableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        [self.homePageTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([self.homePageTableView respondsToSelector:@selector(setLayoutMargins:)])
    {
        [self.homePageTableView setLayoutMargins:UIEdgeInsetsZero];
    }
}
/** 添加刷新控件*/
-(void)setupMsgRefresh
{
    //下拉刷新控件
    self.homePageTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewDynamic)];
    [self loadNewDynamic];
    //自定义footer
    self.homePageTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDynamic)];
    
}
-(void)loadNewDynamic
{
    [self.homePageTableView.mj_footer endRefreshing];
    //无网络状态也需要赋值（之前保存在偏好设置里面的数据）
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reach currentReachabilityStatus];
    if (status == NotReachable) {//无网络
        [MBProgressHUD showError:@"请检查网络后重试"];
    }else//网络请求
    {
        NSMutableArray *temp = [NSMutableArray array];
        for (int i=0; i<10; i++) {
            NSString *str = [NSString stringWithFormat:@"数据：%zd",i];
            [temp addObject:str];
        }
        //结束刷新状态
        [self.homePageTableView.mj_header endRefreshing];
        //刷新控件
        self.modelArray = temp;
        //控制footer的状态
        if (temp.count==0) {
            //没有更多数据了
            self.homePageTableView.mj_footer.hidden = YES;
        }else if (temp.count < 10) {
            //全部加载完毕
            [self.homePageTableView.mj_footer endRefreshingWithNoMoreData];
        }
        
    }
    
}
-(void)loadMoreDynamic
{
    [self.homePageTableView.mj_header endRefreshing];
    //无网络状态也需要赋值（之前保存在偏好设置里面的数据）
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reach currentReachabilityStatus];
    if (status == NotReachable) {//无网络
        [MBProgressHUD showError:@"请检查网络后重试"];
    }else//网络请求
    {
        NSMutableArray *totalArray = [NSMutableArray arrayWithArray:self.modelArray];
        NSMutableArray *tempArray = [NSMutableArray array];
        for (int i=0; i<10; i++) {
            NSString *str = [NSString stringWithFormat:@"数据：%zd",i];
            [tempArray addObject:str];
        }
        //控制footer的状态
        if (tempArray.count < 10) {
            //全部加载完毕
            [self.homePageTableView.mj_footer endRefreshingWithNoMoreData];
        }else
        {
            //结束刷新状态
            [self.homePageTableView.mj_footer endRefreshing];
            
        }
        //最新评论
        [totalArray addObjectsFromArray:tempArray];
        self.modelArray = totalArray;
    }
}
-(void)setModelArray:(NSArray *)modelArray
{
    _modelArray = modelArray;
    [self.homePageTableView reloadData];
}
- (void)viewDidLoad{
    [super viewDidLoad];
    if (!self.allowPullToRefresh) {
        return;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(takeBack:) name:kHHHorizontalTakeBackRefreshEndNotification object:self.tableView];
    
    __weak typeof(self)weakSelf = self;
    [self.tableView addPullToRefreshOffset:self.pullOffset withActionHandler:^{
        [[NSNotificationCenter defaultCenter] postNotificationName:kHHHorizontalScrollViewRefreshStartNotification object:weakSelf.tableView userInfo:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.tableView.pullToRefreshView stopAnimating];
            [[NSNotificationCenter defaultCenter] postNotificationName:kHHHorizontalScrollViewRefreshEndNotification object:weakSelf.tableView userInfo:nil];
        });
    }];
}

- (void)takeBack:(NSNotification *)noti{
    [self.tableView.pullToRefreshView stopAnimating:NO];
}

- (void)dealloc{
    NSLog(@"%s",__func__);
}

#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellid = @"cellid";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        cell.textLabel.textColor = kThemeColor;
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%@%@",self.index?@"评论":@"帖子",self.modelArray[indexPath.row]];
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    self.homePageTableView.mj_footer.hidden = (self.modelArray.count == 0);
    if (self.modelArray.count < 10 && self.modelArray.count > 0) {
        //全部加载完毕
        [self.homePageTableView.mj_footer endRefreshingWithNoMoreData];
    }
    return self.modelArray.count;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
    
}

#pragma mark - <点击进去详情页>
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.homePageTableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0001;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    // 通过最后一个 Footer 来补高度
    if (section == [self numberOfSectionsInTableView:tableView] - 1) {
        return [self automaticHeightForTableView:tableView];
    }
    return 0.0001;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = kBgColor;
    return view;
}

- (CGFloat)automaticHeightForTableView:(UITableView *)tableView{
    
      // 36 是 segmentButtons 的高度 20 是segmentTopSpace的高度
    CGFloat height = self.fillHight;
    
    NSInteger section = [tableView.dataSource numberOfSectionsInTableView:tableView];
    for (int i = 0; i < section; i ++) {
        
        if ([tableView.delegate respondsToSelector:@selector(tableView:heightForHeaderInSection:)]) {
            height += [tableView.delegate tableView:tableView heightForHeaderInSection:i];
        }
        
        NSInteger row = [tableView.dataSource tableView:tableView numberOfRowsInSection:i];
        for (int j= 0 ; j < row; j++) {
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:j inSection:i];
            if ([tableView.delegate respondsToSelector:@selector(tableView:heightForRowAtIndexPath:)]) {
                height += [tableView.delegate tableView:tableView heightForRowAtIndexPath:indexPath];
            }
            
            if (height >= tableView.frame.size.height) {
                return 0.0001;
            }
        }
        
        if (i != section - 1) {
            
            if ([tableView.delegate respondsToSelector:@selector(tableView:heightForFooterInSection:)]) {
                height += [tableView.delegate tableView:tableView heightForFooterInSection:i];
            }
        }
        
    }
    
    if (height >= tableView.frame.size.height) {
        return 0.0001;
    }
    
    return tableView.frame.size.height - height;
}
@end
