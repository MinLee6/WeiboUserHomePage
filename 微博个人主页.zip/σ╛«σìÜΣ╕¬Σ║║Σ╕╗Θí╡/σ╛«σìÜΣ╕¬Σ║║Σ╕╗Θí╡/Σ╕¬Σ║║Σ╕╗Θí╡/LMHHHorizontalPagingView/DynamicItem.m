//
//  DynamicItem.m
//  Demo
//
//  Created by weijingyun on 16/12/3.
//  Copyright © 2016年 weijingyun. All rights reserved.
//

#import "DynamicItem.h"

@implementation DynamicItem

- (instancetype)init {
    if (self = [super init]) {
        _bounds = CGRectMake(0, 0, 1, 1);
    }
    return self;
}

//- (void)dealloc{
//    NSLog(@"%s",__func__);
//}

@end
