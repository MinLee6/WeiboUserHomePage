//
//  ViewController.m
//  微博个人主页
//
//  Created by limin on 17/1/4.
//  Copyright © 2017年 君安信（北京）科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "LMMyHomeController.h"
@interface ViewController ()
/* 进入个人主页按钮 */
@property(nonatomic,strong)UIButton *enterUserHome;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(15, 100, 200, 40)];
    [btn setTitle:@"进入个人主页" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setBackgroundColor:[UIColor lightGrayColor]];
    [btn addTarget:self action:@selector(enterUserHomeClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    self.enterUserHome = btn;
}
-(void)enterUserHomeClick
{
    LMMyHomeController *homeVC = [[LMMyHomeController alloc]init];
    [self.navigationController pushViewController:homeVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
